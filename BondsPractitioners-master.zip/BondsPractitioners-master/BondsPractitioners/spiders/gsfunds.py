# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *

class GsfundsSpider(scrapy.Spider):
    name = 'gsfunds'
    allowed_domains = ['gsfunds.com.cn']
    start_urls = ['http://www.gsfunds.com.cn/Aboutus/inquire/index.html']
    com_name = '国寿安保基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        table = response.css('table')[-1]
        for tr in table.css('tr')[2:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            td = [a.strip() for a in td]
            yield set_item(['com', 'state', 'kind', 'name', 'duty', 'phone', 'other'],
                           [self.com_name, '在职', '前台'] + td)