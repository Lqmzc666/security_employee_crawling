# -*- coding: utf-8 -*-
import scrapy
import os
import pdfplumber
from BondsPractitioners.spiders import set_item


class OrientFundSpider(scrapy.Spider):
    name = 'orient-fund'
    allowed_domains = ['orient-fund.com']
    start_urls = ['http://www.orient-fund.com/zzcx/index.html']
    com_name = '东方基金管理有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        url = response.css('div.listText *::attr(href)').getall()[0]
        basic_url = 'http://www.orient-fund.com'
        yield scrapy.Request(url=basic_url+url, callback=self.parse_pdf)

    def parse_pdf(self, response):
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'orient-fund.pdf')
        with open(file_name, 'wb') as f:
            f.write(response.body)

        tables = []
        with pdfplumber.open(file_name) as pdf:
            for page in pdf.pages:
                for table in page.extract_tables():
                    for data in table:
                        tables.append([row for row in data if row])

        tables = [table for table in tables if table]
        index = []  # 标记每张表格起始位置
        i = 0
        for table in tables:
            if table:
                if table[0] == '职能分类' or table[0] == '姓名':
                    index.append(i)
            i += 1

        #处理在职人员
        for i in range(index[0] + 1, index[1]):
            if len(tables[i]) == 6:
                kind = tables[i][0]
            if kind == '业务人员':
                if 5 <= len(tables[i]) <= 6:
                    job = tables[i][-5]
                    tables[i] = tables[i][-4:]
                if len(tables[i]) > 1:
                    yield set_item(['com', 'kind', 'state', 'job', 'name', 'phone'],
                                   [self.com_name, '前台', '在职', job] + [tables[i][0]]+[tables[i][-1]])

            if kind != '业务人员':
                if 5 <= len(tables[i]) <= 6:
                    job = tables[i][-5]
                    tables[i] = tables[i][-4:]
                if len(tables[i]) > 1:
                    yield set_item(['com', 'kind', 'state', 'job', 'name', 'phone'],
                                   [self.com_name, '中后台', '在职', job] + [tables[i][0]]+[tables[i][-1]])

        for i in range(index[1] + 1, len(tables)):
            if len(tables[i]) == 4:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + tables[i])

