# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *


class CsfundsSpider(scrapy.Spider):
    name = 'csfunds'
    allowed_domains = ['csfunds.com.cn']
    start_urls = ['http://www.csfunds.com.cn/qtnrgl/xsgs/']
    com_name = '长盛基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        for tr in tables[-2].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('p *::text').getall()) for a in td]  # 将span中的文字拼接起来
            if len(td) > 5:
                td = td[1:]
            td = [a.strip() for a in td]
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                if job != '债券交易核对专岗':
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                                   [self.com_name, '在职', '前台', job] + td[-4:])
                else:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                                   [self.com_name, '在职', '中后台', job] + td[-4:])

        for tr in tables[-1].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('p *::text').getall()) for a in td]  # 将span中的文字拼接起来
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) > 2:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])
