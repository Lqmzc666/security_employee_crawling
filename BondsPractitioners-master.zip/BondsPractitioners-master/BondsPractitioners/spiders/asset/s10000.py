# -*- coding: utf-8 -*-
import scrapy
import json
from BondsPractitioners.spiders import set_item
from scrapy import Selector

class S10000Spider(scrapy.Spider):
    name = 's10000'
    allowed_domains = ['s10000.com']
    start_urls = ['http://www.s10000.com/cdzq/wsyyt/detail.html/']
    com_name = '财达证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'http://www.s10000.com/JSONService/rewin_getFirstNr.jsp'
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        body = 'classid=00010002000400020012&datalen=content&hrefURL=&filter=&jsontype=json'
        yield scrapy.Request(url=url, method='POST', headers=headers, body=body)

    def parse(self, response):
        tables = Selector(text=json.loads(response.text).get('result')[0].get('content')).css('table')
        # 处理证券+固定收益人员
        for table in tables[2:4]:
            for rows in table.css('tr')[1:]:
                td = rows.css('td p span::text').getall()
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理资管人员
        for rows in tables[0].css('tr')[1:]:
            td = rows.css('td p span::text').getall()
            yield set_item(['com', 'state', 'kind', 'name', 'job', 'dpt'],
                           [self.com_name, '在职', '前台'] + td[-3:])

        # 处理中后台人员
        for rows in tables[4].css('tr')[1:]:
            td = rows.css('td')
            td = [''.join(a.css('p span::text').getall()) for a in td]
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        for rows in tables[1].css('tr')[1:]:
            td = rows.css('td')
            td = [''.join(a.css('p span::text').getall()) for a in td]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台'] + td[-4:])
