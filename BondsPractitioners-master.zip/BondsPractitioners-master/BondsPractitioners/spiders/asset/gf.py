# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class GfSpider(scrapy.Spider):
    name = 'gf'
    allowed_domains = ['gf.com']
    start_urls = ['http://www.gf.com.cn/about/news/bondtradingInfo/']
    com_name = '广发证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')

        #处理前台自营业务人员
        for rows in tables[0].css('tr')[1:]:
            td = rows.css('td::text').getall()
            if len(td) == 4:
                job = td[0]
            if 3 <= len(td) <= 4:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理前台投顾业务人员
        for rows in tables[2].css('tr')[1:]:
            td = rows.css('td::text').getall()
            if len(td) == 3:
                job = td[0]
            if 2 <= len(td) <= 3:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt'],
                               [self.com_name, '在职', '前台', job] + td[-2:])

        # 处理中后台人员
        for rows in tables[1].css('tr')[1:]:
            td = rows.css('td::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for rows in tables[3].css('tr')[1:]:
            td = rows.css('td::text').getall()
            if 3 <= len(td) <= 4:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])