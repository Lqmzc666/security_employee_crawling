# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import json


class NescSpider(scrapy.Spider):
    name = 'nesc'
    allowed_domains = ['nesc.cn']
    start_urls = ['http://www.nesc.cn/dbzq/wsyyt/khzq/zyztjyry/zyztjyry_list.jsp?classid=0001000100020001000400240003/']
    com_name = '东北证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = ['http://www.nesc.cn/dbzq/wsyyt/khzq/zyztjyry/getZyztjyry.jsp',
               'http://www.nesc.cn/dbzq/wsyyt/khzq/zyzhthdzg/getDzrhjyry.jsp',
               'http://www.nesc.cn/dbzq/wsyyt/khzq/zylzry/getZylzry.jsp']
        headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.133 Safari/534.16',
                    'X-Requested-With': 'XMLHttpRequest'}
        data = ['name=&gw=&bm=%E8%AF%B7%E9%80%89%E6%8B%A9&classid=56&pageIndex=1&pageSize=10',
                'name=&gw=&bm=%E8%AF%B7%E9%80%89%E6%8B%A9&classid=57&pageIndex=1&pageSize=100',
                'name=&gw=&bm=%E8%AF%B7%E9%80%89%E6%8B%A9&classid=58&pageIndex=1&pageSize=10']
        func = [self.parse_front, self.parse_back, self.parse_dis]
        for i in range(0, 3):
           yield scrapy.Request(url=url[i], headers=headers, body=data[i], method='POST', callback=func[i])

    # 处理前台人员
    def parse_front(self, response):
        results = json.loads(response.text).get('result')
        data = ['gw', 'xm', 'bm', 'zw']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台']+[result.get(index) for index in data])
    # 处理中后台人员
    def parse_back(self, response):
        results = json.loads(response.text).get('result')
        data = ['gw', 'xm', 'bm', 'zw', 'lxfs']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                     [self.com_name, '在职', '中后台'] + [result.get(index) for index in data])

    # 处理离职人员
    def parse_dis(self, response):
        results = json.loads(response.text).get('result')
        data = ['xm', 'lzrq', 'bm', 'zw']
        for result in results:
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + [result.get(index) for index in data])

