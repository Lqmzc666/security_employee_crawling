# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class HlzqgsSpider(scrapy.Spider):
    name = 'hlzqgs'
    allowed_domains = ['hlzqgs.com']
    start_urls = ['http://www.hlzqgs.com/main/a/20181106/72033252.shtml']
    com_name = '华龙证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table.MsoNormalTable')

        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td')
                td = [''.join(a.css('p span::text').getall()) for a in td]  # 将span中的文字拼接起来
                td = list(filter(None, [a.strip() for a in td]))
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('p span::text').getall()) for a in td]  # 将span中的文字拼接起来
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '前台', job] + td[-4:])

        # 处理中后台人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('p span::text').getall()) for a in td]
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员(网站未有离职人员)
        '''
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            td = list(filter(None, [a.strip() for a in td]))
            if td:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])
        '''

