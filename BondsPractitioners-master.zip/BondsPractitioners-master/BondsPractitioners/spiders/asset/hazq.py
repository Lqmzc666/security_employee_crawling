# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import json

class HazqSpider(scrapy.Spider):
    name = 'hazq'
    allowed_domains = ['hazq.com']
    start_urls = ['http://hazq.com/hazq/zjha/xxgs/xxgs.jsp?classid=0001000100080015']
    com_name = '华安证券股份有限公司'
    author = 'Qi_Li'

    url = 'http://hazq.com/hazq/zjha/xxgs/xxgsAction.jsp'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
    data = ['yyb=&act=6&pageIndex=1&name=&code=&rytype=1',  # 自营
            'yyb=&act=6&pageIndex=1&name=&code=&rytype=2',  # 资管
            'yyb=&act=6&pageIndex=1&name=&code=&rytype=3',  # 中后台
            'yyb=&act=6&pageIndex=1&name=&code=&rytype=0']  # 离职

    def start_requests(self):
        yield scrapy.Request(url=self.url, headers=self.headers, body=self.data[0], method='POST', callback=self.parse_front1)
        yield scrapy.Request(url=self.url, headers=self.headers, body=self.data[1], method='POST', callback=self.parse_front2)
        yield scrapy.Request(url=self.url, headers=self.headers, body=self.data[2], method='POST', callback=self.parse_back)
        yield scrapy.Request(url=self.url, headers=self.headers, body=self.data[3], method='POST', callback=self.parse_dis)

    # 处理自营业务
    def parse_front1(self, response):
        results = json.loads(response.text).get('result')
        data = ['gwfl', 'name', 'szbm', 'position']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台'] + [result.get(index) for index in data])
        for i in range(2, 6):
            body = f'yyb=&act=6&pageIndex={str(i)}&name=&code=&rytype=1'
            yield scrapy.Request(url=self.url, headers=self.headers, body=body, method='POST', callback=self.parse_front1)

    # 处理资管人员
    def parse_front2(self, response):
        results = json.loads(response.text).get('result')
        data = ['gwfl', 'name', 'szbm', 'position']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台'] + [result.get(index) for index in data])
        for i in range(2, 6):
            body = f'yyb=&act=6&pageIndex={str(i)}&name=&code=&rytype=2'
            yield scrapy.Request(url=self.url, headers=self.headers, body=body, method='POST', callback=self.parse_front2)

    def parse_back(self, response):
        results = json.loads(response.text).get('result')
        data = ['gwfl', 'name', 'szbm', 'position', 'phone']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '中后台'] + [result.get(index) for index in data])
    def parse_dis(self, response):
        pass    # 没有人员名单，不知道字典键值
        '''
        results = json.loads(response.text).get('result')
        data = ['gwfl', 'name', 'szbm', 'position', 'phone']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '前台'] + [result.get(index) for index in data])
        '''
