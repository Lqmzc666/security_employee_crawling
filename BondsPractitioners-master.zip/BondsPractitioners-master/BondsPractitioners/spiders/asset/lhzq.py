# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import docx
from docx import Document
import os
from BondsPractitioners.spiders import doc2docx

class LhzqSpider(scrapy.Spider):
    name = 'lhzq'
    allowed_domains = ['lhzq.com']
    start_urls = ['https://www.lhzq.com/main/a/20181105/10000603.shtml']
    com_name = '华泰联合证券有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        basic_url = 'https://www.lhzq.com'
        href = response.css('a[target=_blank]::attr(href)').get()
        new_url = basic_url + href
        yield scrapy.Request(url=new_url, callback=self.parse_word)

    def parse_word(self, response):
        # 下载doc文件
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'lhzq.doc')
        with open(file_name, 'wb') as f:
            f.write(response.body)

        doc2docx(file_name)

        # 读取docx文件
        document = Document(os.path.join(file_path, 'lhzq.docx'))
        tables = document.tables


        # 处理前台人员
        for i in range(1, len(tables[0].rows)):
            data = [tables[0].cell(i, j).text for j in range(0, 4)]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台'] + data)

        # 处理中后台人员
        for i in range(1, len(tables[1].rows)):
            data = [tables[1].cell(i, j).text for j in range(0, 5)]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '中后台'] + data)

        # 处理离职人员(无离职人员)
        '''
        for i in range(1, len(tables[2].rows)):
            data = [tables[2].cell(i, j).text for j in range(0, 4)]
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + data)
        '''