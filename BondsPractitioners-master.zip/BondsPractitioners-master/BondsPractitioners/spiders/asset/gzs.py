# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class GzsSpider(scrapy.Spider):
    name = 'gzs'
    allowed_domains = ['gzs.com']
    start_urls = ['http://www.gzs.com.cn/main/a/20190621/17161840.shtml']
    com_name = '广州证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')

        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td p span::text').getall()
                data = list(filter(None, [a.strip() for a in td]))
                if len(data) == 4:
                    job = data[0]
                if 3 <= len(data) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + data[-3:])

        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            data = list(filter(None, [a.strip() for a in td]))
            if len(data) == 5:
                job = data[0]
            if 4 <= len(data) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + data[-4:])

        # 处理离职人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            data = list(filter(None, [a.strip() for a in td]))
            if data:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + data[-4:])
