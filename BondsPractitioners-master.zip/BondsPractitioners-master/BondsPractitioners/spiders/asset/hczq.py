# -*- coding: utf-8 -*-
import scrapy
import requests

class HczqSpider(scrapy.Spider):
    name = 'hczq'
    allowed_domains = ['hczq.com']
    start_urls = ['https://www.hczq.com/hczq/getInfoDetail.do?hczqInfoId=3494']
    com_name = '华创证券有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        print(response.text)
