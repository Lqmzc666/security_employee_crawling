# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import re
from scrapy import Selector


class DxzqSpider(scrapy.Spider):
    name = 'dxzq'
    allowed_domains = ['dxzq.net']
    start_urls = ['http://www.dxzq.net/main/a/20181218/2595.shtml']
    com_name = '东兴证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = Selector(text=response.text).css('table')
        # 处理前台人员
        for table in tables[:2]:
            for rows in table.css('tr')[1:]:
                td = rows.css('td::text').getall()
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4 and td[1] != '\u3000':  # 空格用\u3000替代
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        # 中后台人员
        for rows in tables[2].css('tr')[1:]:
            td = rows.css('td')
            data = [''.join(tx.css('*::text').getall()) for tx in td]   # job的值不在同一个标签底下
            if len(data) == 5:
                job = data[0]
            if 4 <= len(data) <= 5 and data[1] != '\u3000' and data[1] != "":
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + data[-4:])

        # 离职人员
        for rows in tables[-1].css('tr')[1:]:
            td = rows.css('td *::text').getall()  # 年份在span里
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])

