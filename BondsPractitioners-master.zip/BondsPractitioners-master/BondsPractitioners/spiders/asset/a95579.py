# -*- coding: utf-8 -*-
import scrapy
import json
from BondsPractitioners.spiders import set_item

class A95579Spider(scrapy.Spider):
    name = '95579'
    allowed_domains = ['95579.com']
    start_urls = ['https://www.95579.com/servlet/infodisclosure/InfoDisclosure']
    com_name = '长江证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'https://www.95579.com/servlet/infodisclosure/InfoDisclosure'
        headers = {'authority': 'www.95579.com',
                 'method': 'POST',
                 'accept - encoding': 'gzip, deflate, br',
                 'accept - language': "en - US, en;q = 0.9",
                 'cookie': 'J_SESSION_ID=A083FB9DEE5C48D28407F59AB88BFDE5; J_SESSION_KEY=ca6c2b5555dbeda5f76dce164ec6f279; J_SESSION_TIME=1562579764603',
                 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
                 'x-requested-with': 'XMLHttpRequest'}
        data = [{'function': 'QueryBondEmployees','i_business_type': '1','i_page': '1', 'i_perpage': '30'},
                {'function': 'QueryBondEmployees', 'i_business_type': '2', 'i_page': '1', 'i_perpage': '30'},
                {'function': 'QueryBondEmployees', 'i_business_type': '4', 'i_page': '1', 'i_perpage': '30'},
                {'function': 'QueryBondDimissionEmployees', 'i_page': '1', 'i_perpage': '30'}]
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[0], callback=self.parse)
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[1], callback=self.parse)
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[2], callback=self.parse_backdesk)
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[3], callback=self.parse_dimission)

    def parse(self, response):
        result = json.loads(response.text).get('data').get('list')
        #处理前台人员
        for row in result:
           row.pop('total_rows')
           yield set_item(['com', 'kind', 'state', 'name', 'code', 'duty', 'phone', 'dpt', 'job'],
                          [self.com_name, '前台', '在职'] + list(row.values()))

    def parse_backdesk(self, response):
        result = json.loads(response.text).get('data').get('list')
        # 处理中后台人员
        for row in result:
            row.pop('total_rows')
            yield set_item(['com', 'kind', 'state', 'name', 'code', 'duty', 'phone', 'dpt', 'job'],
                           [self.com_name, '中后台', '在职'] + list(row.values()))

    def parse_dimission(self, response):
        result = json.loads(response.text).get('data').get('list')
        # 处理离职人员
        for row in result:
            row.pop('total_rows')
            yield set_item(['com', 'state', 'name', 'duty', 'dpt', 'ldate'],
                           [self.com_name, '离职'] + list(row.values()))
