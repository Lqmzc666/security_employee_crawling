# -*- coding: utf-8 -*-
import scrapy
from scrapy import Selector
from BondsPractitioners.spiders import set_item

class CczqSpider(scrapy.Spider):
    name = 'cczq'
    allowed_domains = ['cczq.com']
    start_urls = ['http://www.cczq.com/main/khfw/debtmaninfo/index.shtml']
    com_name = '川财证券有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = Selector(text=response.text).css('table')
        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td p span::text').getall()
                if len(td) == 4 and len(td[2])>2:   # 确保第二个关键字不是无
                    job = td[0]
                if 3 <= len(td) <= 4 and len(td[2])>2:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) == 5 and len(td[2]) > 2:
                job = td[0]
            if 4 <= len(td) <= 5 and len(td[2]) > 2:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for rows in tables[-1].css('tr')[1:]:
            td = rows.css('td p span::text').getall()
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty', 'other'],
                               [self.com_name, '离职'] + td[-5:])