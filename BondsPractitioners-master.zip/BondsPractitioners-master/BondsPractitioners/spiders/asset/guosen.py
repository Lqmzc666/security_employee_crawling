# -*- coding: utf-8 -*-
import scrapy
import json
from scrapy import Selector
from BondsPractitioners.spiders import set_item

class GuosenSpider(scrapy.Spider):
    name = 'guosen'
    allowed_domains = ['guosen.com.cn']
    start_urls = ['http://www.guosen.com.cn/gs/about_guosen/public_inform_securityDeal.html#nav/']
    com_name = '国信证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'http://www.guosen.com.cn/gswz-web/info/list/1.0?id=31043'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
                   'X-Requested-With': 'XMLHttpRequest'}
        data = {'id': '31043'}
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data, method='POST', callback=self.parse)

    def parse(self, response):
        tables = Selector(text=json.loads(response.text).get('data')[0].get('content')).css('table')

        # 处理前台人员
        for table in tables[0:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td')
                td = [''.join(a.css('*::text').getall()) for a in td]  #处理文字不在一个标签下的问题
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('p span::text').getall()) for a in td]
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td')
            td = list(filter(None, [a.strip() for a in td]))    # 去掉换行符
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])

