# -*- coding: utf-8 -*-
import scrapy
from scrapy import Selector
import json
from BondsPractitioners.spiders import set_item

class GjzqSpider(scrapy.Spider):
    name = 'gjzq'
    allowed_domains = ['gjzq.com.cn']
    start_urls = ['http://www.gjzq.com.cn/service/article/4435557?_=1564478619843']
    com_name = '国金证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = Selector(text=json.loads(response.text).get('data').get('content')).css('table')

        # 处理前台人员
        for table in tables[0:2]+[tables[3]]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td p span::text').getall()
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])
        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for tr in tables[-1].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])