# -*- coding: utf-8 -*-
import scrapy
import json
from BondsPractitioners.spiders import set_item


class HtscSpider(scrapy.Spider):
    name = 'htsc'
    allowed_domains = ['web.htsc.com']
    start_urls = ['http://web.htsc.com.cn/aboutht/rygs/index.jsp/']
    com_name = '华泰证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'http://web.htsc.com.cn/aboutht/rygs/getRygsOfBonds.do'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
                   'X-Requested-With': 'XMLHttpRequest'}
        data = ''
        yield scrapy.Request(url=url, headers=headers, body=data, method='POST', callback=self.parse)

    def parse(self, response):
        results = json.loads(response.text).get('resultData')

        # 处理前台人员
        data_front = ['name', 'department', 'duty']
        job = ''
        for result in results.get('ywry'):
            data = [result.get(a) for a in data_front]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台', job] + data)

        # 处理中后台人员
        data_back = ['name', 'department', 'duty', 'telephone']
        job = ''
        for result in results.get('zhtry'):
            data = [result.get(a) for a in data_back]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '中后台', job] + data)

        # 处理离职人员
        data_dis = ['name', 'leadate', 'department', 'duty', ]
        job = ''
        for result in results.get('lzry'):
            data = [result.get(a) for a in data_dis]
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '在职'] + data)





