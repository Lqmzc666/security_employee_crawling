# -*- coding: utf-8 -*-
import scrapy
import pdfplumber
import os
from BondsPractitioners.spiders import set_item

class CfzqSpider(scrapy.Spider):
    name = 'cfzq'
    allowed_domains = ['cfzq.com']
    start_urls = ['https://www.cfzq.com/u/cms/www/201906/211538050ll6.pdf']
    com_name = '财富证券有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        # 获取返回数据，并保存为pdf文件
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'cfzq.pdf')
        with open(file_name, 'wb') as f:
            f.write(response.body)

        tables = []
        with pdfplumber.open(file_name) as pdf:
            for page in pdf.pages:
                for table in page.extract_tables():
                    for data in table:
                        tables.append([row for row in data if row])

        index = []  # 标记每张表格起始位置
        i = 0
        for table in tables:
            if table:
                if table[0] == '岗位分类' or table[0] == '姓名':
                    index.append(i)
            i += 1

        # 处理前台人员
        for j in range(3):
            for i in range(index[j] + 1, index[j + 1]):
                if 3 <= len(tables[i]) <= 4:
                    yield set_item(['com', 'kind', 'state', 'name', 'dpt', 'duty'],
                                   [self.com_name, '前台', '在职'] + tables[i][-3:])

            # 处理中后台人员
        for i in range(index[3] + 1, index[4]):
            if 4 <= len(tables[i]) <= 5:      # 代表是正常的一行
                yield set_item(['com', 'kind', 'state', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '中后台', '在职'] + tables[i][-4:])

            # 处理离职人员
        for i in range(index[4] + 1, len(tables)):
            if len(tables[i]) == 4:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + tables[i])