# -*- coding: utf-8 -*-
import scrapy
from scrapy import Selector
import re
from BondsPractitioners.spiders import set_item


class CgwsSpider(scrapy.Spider):
    name = 'cgws'
    allowed_domains = ['cgws.com']
    start_urls = ['http://www.cgws.com/cczq/gycc/zqjyrygs/']
    com_name = '长城证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        #处理前台资管人员
        pattern = re.compile('showData.*?else\{(.*?)\}', re.S)
        result = re.search(pattern, response.text)
        pattern_ = re.compile('html.push\((.*?)\)')
        results = re.findall(pattern_, result.group(1))

        for i in results[1:]:
            row = Selector(text=i).css('td::text').getall()
            if len(row) == 4:
                job = row[0]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台', job]+row[-3:])

        #处理后台资管人员
        pattern = re.compile('showData.*?if.*?\{(.*?)\}', re.S)
        result = re.search(pattern, response.text)
        pattern_ = re.compile('html.push\((.*?)\)')
        results = re.findall(pattern_, result.group(1))

        for i in results[1:]:
            row = Selector(text=i).css('td::text').getall()
            if len(row) == 5:
                job = row[0]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '中后台', job]+row[-4:])

        #处理前台固定收益人员
        pattern = re.compile('showGdsyData.*?else\{(.*?)\}', re.S)
        result = re.search(pattern, response.text)
        pattern_ = re.compile('html.push\((.*?)\)')
        results = re.findall(pattern_, result.group(1))

        name = {}  # 防止人员名字重复
        for i in results[1:]:
            row = Selector(text=i).css('td::text').getall()
            if len(row) == 4:
                job = row[0]
            if not name.get(row[-3]):
                name[row[-3]] = True
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + row[-3:])

        #处理中后台固定收益人员
        pattern = re.compile('showGdsyData.*?if.*?\{(.*?)\}', re.S)
        result = re.search(pattern, response.text)
        pattern_ = re.compile('html.push\((.*?)\)')
        results = re.findall(pattern_, result.group(1))

        for i in results[1:]:
            row = Selector(text=i).css('td::text').getall()
            if len(row) == 5:
                job = row[0]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '中后台', job]+row[-4:])