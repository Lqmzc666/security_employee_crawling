# -*- coding: utf-8 -*-
import scrapy
import json
from BondsPractitioners.spiders import set_item

class EasecSpider(scrapy.Spider):
    name = 'easec'
    allowed_domains = ['easec.com.cn']
    start_urls = ['http://www.easec.com.cn/osoa/views/about/index.html?t=publicity/']
    com_name = '东亚前海证券有限责任公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'http://www.easec.com.cn/servlet/json'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
                   'X-Requested-With': 'XMLHttpRequest'}
        data = [{'funcNo': '905039', 'type': '1','pageSize': '1', 'pageNum': '10'},
                {'funcNo': '905039', 'type': '2', 'pageSize': '1', 'pageNum': '10'},
                {'funcNo': '905039', 'type': '3', 'pageSize': '1', 'pageNum': '10'}]
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[0], method='POST', callback=self.parse_front)
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[1], method='POST', callback=self.parse_back)
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[2], method='POST', callback=self.parse_dis)

    # 处理前台人员
    def parse_front(self, response):
        results = json.loads(response.text).get('results')[0].get('data')
        data = ['bond_post', 'bond_name', 'bond_department', 'jurisdiction']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'other'],
                           [self.com_name, '在职', '前台'] + [result.get(name) for name in data])

    # 处理中后台人员
    def parse_back(self, response):
        results = json.loads(response.text).get('results')[0].get('data')
        data = ['bond_post', 'bond_name', 'bond_department', 'contact_information']
        for result in results:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'phone'],
                           [self.com_name, '在职', '中后台'] + [result.get(name) for name in data])

    # 处理离职人员
    def parse_dis(self, response):
        pass
        results = json.loads(response.text).get('results')[0].get('data')
        data = ['bond_post', 'bond_name', 'bond_department', 'departure_date']
        for result in results:
            yield set_item(['com', 'state', 'job', 'name', 'dpt', 'ldate'],
                           [self.com_name, '离职'] + [result.get(name) for name in data])
