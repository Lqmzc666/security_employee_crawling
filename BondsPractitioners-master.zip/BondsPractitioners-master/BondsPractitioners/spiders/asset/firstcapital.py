# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import json

class FirstcapitalSpider(scrapy.Spider):
    name = 'firstcapital'
    allowed_domains = ['firstcapital.com.cn']
    start_urls = ['http://www.firstcapital.com.cn/main/gyyc/ryxx/khjl/index.html#']
    com_name = '第一创业证券股份有限公司'
    author = 'Qi_Li'
    url = 'https://www.firstcapital.com.cn/servlet/json'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
    data = ['funcNo=904334&page=1&numPage=10&isIncumbency=1',  # 债券在职人员
            'funcNo=904334&page=1&numPage=10&isIncumbency=0']  # 债券离职人员

    def start_requests(self):
        yield scrapy.Request(url=self.url, headers=self.headers, body=self.data[0], method='POST', callback=self.parse_bond)
        #yield scrapy.Request(url=self.url, headers=self.headers, body=self.data[1], method='POST', callback=self.parse_dis)

    def parse_bond(self, response):
        result = json.loads(response.text).get('results')[0]
        total_page = result.get('totalPages')  # 获取下一页页码作为post参数传递
        data = result.get('data')
        for row in data:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台', row.get('station'), row.get('name'), row.get('branch'), row.get('post')])
        for i in range(2, total_page+1):
            body = f'funcNo=904334&page={str(i)}&numPage=10&isIncumbency=1'
            yield scrapy.Request(url=self.url, headers=self.headers, body=body, method='POST', callback=self.parse_bond)

    def parse_asset(self, response):
        result = json.loads(response.text).get('results')[0]
        total_page = result.get('totalPages')  # 获取下一页页码作为post参数传递
        data = result.get('data')
        for row in data:
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台', row.get("sm_station"), row.get("sm_name"), row.get("sm_branch"), row.get("sm_post")])
        for i in range(2, total_page+1):
            body = f'funcNo=904334&page={str(i)}&numPage=10&isIncumbency=0'
            yield scrapy.Request(url=self.url, headers=self.headers, body=body, method='POST', callback=self.parse_bond)
