# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import json
from scrapy import Selector


class DgzqSpider(scrapy.Spider):
    name = 'dgzq'
    allowed_domains = ['new.dgzq.com.cn']
    start_urls = ['https://new.dgzq.com.cn/dz-ow/system/aticle/queryContent/']
    com_name = '东莞证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'https://new.dgzq.com.cn/dz-ow/system/aticle/queryContent'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
                   'X-Requested-With': 'XMLHttpRequest'}
        data = {'articleId': '455'}
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data, method='POST', callback=self.parse)

    def parse(self, response):
        result = json.loads(response.text).get('dataSet')[0].get('content')
        tables = Selector(text=result).css('table')[2:]
        front_tables = tables[:2]+[tables[3]]  # 所有前台人员表
        for table in front_tables:
            for rows in table.css('tr')[1:]:
                td = rows.css('td')
                data = [''.join(tx.css('p span::text').getall()) for tx in td]
                data = [a.strip() for a in data]
                if not data[0]:    # 有岗位分类空白的情况
                    job = ''
                    data = list(filter(None, [a.strip() for a in data]))
                    if len(data) == 3:
                        yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                       [self.com_name, '在职', '前台', job] + data[-3:])
                else:
                    data = list(filter(None, [a.strip() for a in data]))
                    if len(data) == 4:
                        job = data[0]
                    if 3 <= len(data) <= 4 and data[1]:  # 保证不是空值
                        yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                       [self.com_name, '在职', '前台', job] + data[-3:])

            # 处理中后台人员
        for rows in tables[2].css('tr')[1:]:
            td = rows.css('td p span::text').getall()  # 有的电话外层没有p标签
            try:
                td.remove('\xa0')
            except:
                pass
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

            # 处理离职人员
        for rows in tables[4].css('tr')[1:]:  # 年份被拆开了
            td = rows.css('td')
            if len(td.css('p span::text')) != 0:
                data = [''.join(tx.css('p span *::text').getall()) for tx in td]
                data = list(filter(None, [a.strip() for a in data]))
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + data[-4:])