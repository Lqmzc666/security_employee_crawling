# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class BhhjamcSpider(scrapy.Spider):
    name = 'bhhjamc'
    allowed_domains = ['bhhjamc.com']
    start_urls = ['https://www.bhhjamc.com/contents/2018/10/9-6a4caf32fcb24fe0befb24badb3ffb11.html']
    com_name = '渤海汇金证券资产管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        # 处理前台人员
        for table in tables[:3]:
            for rows in table.css('tr')[1:]:
                td = rows.css('td p::text').getall()
                td = list(filter(None, [a.strip() for a in td]))
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        # 中后台人员
        for rows in tables[3].css('tr')[1:]:
            td = rows.css('td p::text').getall()
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 离职人员
        for rows in tables[-1].css('tr')[1:]:
            td = rows.css('td p *::text').getall()
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])