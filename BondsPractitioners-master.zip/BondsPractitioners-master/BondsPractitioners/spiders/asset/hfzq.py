# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class HfzqSpider(scrapy.Spider):
    name = 'hfzq'
    allowed_domains = ['www.hfzq.com']
    start_urls = ['https://www.hfzq.com.cn/review_cms_db713c1e-3b02-4410-a9e6-c5333f0af7fc.shtm']
    com_name = '华福证券有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')

        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td')
                td = [''.join(a.css('div span::text').getall()) for a in td]  # 将span中的文字拼接起来
                td = list(filter(None, [a.strip() for a in td]))
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('div span::text').getall()) for a in td]
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])
