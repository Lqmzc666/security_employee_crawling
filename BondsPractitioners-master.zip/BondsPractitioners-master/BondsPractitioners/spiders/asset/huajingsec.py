# -*- coding: utf-8 -*-
import scrapy
import pdfplumber
from BondsPractitioners.spiders import set_item
import os


class HuajingsecSpider(scrapy.Spider):
    name = 'huajingsec'
    allowed_domains = ['huajingsec.com']
    start_urls = ['http://www.huajingsec.com/cn/aboutUs/info/3681.shtml']
    com_name = '华菁证券有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        href = response.css('a.download_href::attr(href)').get()
        basic_url = 'http://www.huajingsec.com'
        yield scrapy.Request(url=basic_url+href, callback=self.parse_pdf)

    def parse_pdf(self, response):
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'huajingsec.pdf')
        with open(file_name, 'wb') as f:
            f.write(response.body)
        tables = []
        with pdfplumber.open('DownloadFiles/huajingsec.pdf') as pdf:
            page = pdf.pages[0]
            for table in page.extract_tables():
                for data in table:
                    tables.append([row for row in data if row])

        index = [] # 标记每张表格起始位置
        i = 0
        for table in tables:
            if table[0] == '岗位分类' or table[0] == '姓名':
                index.append(i)
            i += 1

        # 处理前台人员
        for j in range(3):
            for i in range(index[j]+1, index[j+1]):
                if len(tables[i]) == 4:
                    job = tables[i][0]
                if 3 <= len(tables[i]) <= 4:
                    yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '前台', '在职', job] + tables[i][-3:])

        # 处理中后台人员
        for i in range(index[3]+1, index[4]):
            if len(tables[i]) == 5:
                job = tables[i][0]
            if 4 <= len(tables[i]) <= 5:
                yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '中后台', '在职', job] + tables[i][-4:])

        # 处理离职人员
        for i in range(index[4]+1, len(tables)):
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + tables[i])