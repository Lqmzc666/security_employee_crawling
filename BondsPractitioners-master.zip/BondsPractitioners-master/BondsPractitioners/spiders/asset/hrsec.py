# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class HrsecSpider(scrapy.Spider):
    name = 'hrsec'
    allowed_domains = ['hrsec.com']
    start_urls = ['http://www.hrsec.com.cn/main/a/20180129/10016594.shtml']
    com_name = '华融证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')

        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td')
                td = [''.join(a.css('::text').getall()) for a in td]  # 将span中的文字拼接起来
                td = [a.replace('\r\n', "").replace(' ', "") for a in td]   # 去除换行符和空格
                td = list(filter(None, [a.strip() for a in td]))
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        #处理基金债券业务人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td')
            if len(td) == 6:
                effect = td[0].css('::text').get()
            if effect != '中后台人员':
                data = td.css('::text').getall()
                if 4 <= len(data) <= 5:
                    job = data[-4]
                if 3 <= len(data) <= 5:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + data[-3:])
            else:
                data = td.css('::text').getall()
                if 5 <= len(data) <= 6:
                    job = data[-5]
                if 4 <= len(data) <= 6:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                                   [self.com_name, '在职', '中后台', job] + data[-4:])



        # 处理中后台人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('::text').getall()) for a in td]
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员(网站未有离职人员)
        '''
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            td = list(filter(None, [a.strip() for a in td]))
            if td:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])
        '''


