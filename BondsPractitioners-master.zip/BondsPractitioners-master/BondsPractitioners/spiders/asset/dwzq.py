# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import pdfplumber
import os
import json


class DwzqSpider(scrapy.Spider):
    name = 'dwzq'
    allowed_domains = ['dwzq.com.cn']
    start_urls = ['http://www.dwzq.com.cn/xxgs']
    com_name = '东吴证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'http://www.dwzq.com.cn/api/whatWeDo/bondInvestors'
        headers = {'Content-Type': 'application/json;charset=UTF-8'}
        body = json.dumps({"languageFlg": "0"})
        yield scrapy.Request(url=url, headers=headers, body=body, method='POST', callback=self.parse)

    def parse(self, response):
        data = json.loads(json.loads(response.text).get('info').get('list')[0].get('pdfFile')).get('url')
        basic_link = 'http://www.dwzq.com.cn/wwwfile/file'
        yield scrapy.Request(url=basic_link+data, callback=self.parse_pdf)

    def parse_pdf(self, response):
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'dwzq.pdf')
        with open(file_name, 'wb') as f:
            f.write(response.body)
        tables = []
        with pdfplumber.open('DownloadFiles/dwzq.pdf') as pdf:
            for page in pdf.pages:
                for table in page.extract_tables():
                    for data in table:
                        tables.append([row for row in data])
        index = [] # 标记每张表格起始位置
        i = 0
        for table in tables:
            if table[0] == '岗位分类' or table[0] == '姓名':
                index.append(i)
            i += 1

        # 处理前台人员
        for i in range(index[0]+1, index[1]):
            if tables[i][0]:  # 确保不是none
                job = tables[i][0]
            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '前台', '在职', job] + tables[i][1:])

        for i in range(index[1]+1, index[2]):
            if tables[i][0]:  # 确保不是none
                job = tables[i][0]
            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '前台', '在职', job] + tables[i][1:])

        # 处理中后台人员
        for i in range(index[2]+1, index[3]):
            if tables[i][0]:  # 确保不是none
                job = tables[i][0]
            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '中后台', '在职', job] + tables[i][1:])

        # 处理离职人员
        for i in range(index[3]+1, len(tables)):
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + tables[i])