# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class DfzqSpider(scrapy.Spider):
    name = 'dfzq'
    allowed_domains = ['dfzq.com']
    start_urls = ['https://www.dfzq.com.cn/osoa/views/main/home/personpublicity/information/bondsales/index.shtml']
    com_name = '东方证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td::text').getall()
                data = [a.strip() for a in td]
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台'] + data[-4:])

        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td::text').getall()
            data = [a.strip() for a in td]
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '中后台'] + data[-5:])

        # 处理离职人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td::text').getall()
            data = [a.strip() for a in td]
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + data[-4:])