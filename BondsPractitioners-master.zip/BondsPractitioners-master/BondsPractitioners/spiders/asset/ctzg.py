# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class CtzgSpider(scrapy.Spider):
    name = 'ctzg'
    allowed_domains = ['ctzg.com']
    start_urls = ['https://www.ctzg.com/html/xxgs/20181226/100038.html']
    com_name = '财通证券资产管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        # 处理在职人员
        for rows in tables[0].css('tr')[1:]:
            td = rows.css('td')
            if len(td) == 6:
                part = td[0].css('*::text').get()
            if part == '业务人员':
                text = td.css('*::text').getall()
                text = list(filter(None, [a.strip() for a in text]))
                if 4 <= len(text) == 5:
                    job = text[-4]
                if 3 <= len(text) <= 5:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + text[-3:])
            if part == '中后台人员':
                text = td.css('*::text').getall()
                text = list(filter(None, [a.strip() for a in text]))
                if 5 <= len(text) == 6:
                    job = text[-5]
                if 4 <= len(text) <= 6:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                                   [self.com_name, '在职', '中后台', job] + text[-4:])

        # 离职人员
        for rows in tables[-1].css('tr')[1:]:
            td = rows.css('td *::text').getall()
            td = list(filter(None, [a.strip() for a in td]))
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])
