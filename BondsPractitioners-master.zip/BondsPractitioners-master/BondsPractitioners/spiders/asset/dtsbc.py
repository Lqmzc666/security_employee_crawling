# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class DtsbcSpider(scrapy.Spider):
    name = 'dtsbc'
    allowed_domains = ['dtsbc.com.cn']
    start_urls = ['http://www.dtsbc.com.cn/main/tzzyd/tzzbh/cyrygs/zqjyrygs/index.html#11564/']
    com_name = '大同证券有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:    # 有的单元格里会有空格
                td = tr.css('td')
                data = []
                for span in td.css('p span::text').getall():
                    if len(span) != 1:
                        data.append(span)
                if len(data) == 4:
                    job = data[0]
                if 3 <= len(data) <= 4 and data[1] != '无':
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + data[-3:])

        # 处理中后台人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td')
            data = []
            for span in td.css('p span::text').getall():
                if len(span) != 1:
                    data.append(span)
            if len(data) == 5:
                job = data[0]
            if 4 <= len(data) <= 5 and data[1] != '无':
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + data[-4:])

        # 处理离职人员
        for tr in tables[4].css('tr')[1:]:
            td = tr.css('td')
            data = []
            for span in td.css('p span::text').getall():
                if len(span) != 1:
                    data.append(span)
            if 4 <= len(data) <= 5 and data[0] != '无':
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + data[-4:])
