# -*- coding: utf-8 -*-
import scrapy
from scrapy import Selector
from BondsPractitioners.spiders import set_item

class TebonSpider(scrapy.Spider):
    name = 'tebon'
    allowed_domains = ['www.tebon.com.cn/main/a/20180928/51235.html']
    start_urls = ['http://www.tebon.com.cn/main/a/20180928/51235.html']
    com_name = '德邦证券股份有限公司'
    author = 'Qi_Li'


    def parse(self, response):
        tables = Selector(text=response.text).css('table')
        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td p span::text').getall()
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4 and td[1] != "\xa0":  # 去除有长度的空格
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

         # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5 and td[1] != "\xa0":
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for rows in tables[-1].css('tr')[1:]:
            td = rows.css('td p span::text').getall()
            if len(td) != 0 and td[0] != "\xa0":
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty',],
                               [self.com_name, '离职'] + td[-4:])