# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item


class CjzcglSpider(scrapy.Spider):
    name = 'cjzcgl'
    allowed_domains = ['https://www.cjzcgl.com/aboutus/jiaoyi/index.html']
    start_urls = ['https://www.cjzcgl.com/aboutus/jiaoyi/index.html']
    com_name = '长江证券（上海）资产管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')

        # 处理前台人员
        for tr in tables[0].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '前台', job] + td[-4:])

        # 处理中后台人员
        for tr in tables[1].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])
