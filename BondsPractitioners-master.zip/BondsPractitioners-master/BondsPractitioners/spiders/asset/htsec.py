# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class HtsecSpider(scrapy.Spider):
    name = 'htsec'
    allowed_domains = ['htsec.com']
    start_urls = ['https://www.htsec.com/htapi/ht/employee/employeeList?type=1']
    com_name = '海通证券股份有限公司'
    author = 'Qi_Li'
    type = 1   # 判断员工种类
    basic_url = 'https://www.htsec.com/htapi/ht/employee/employeeList?type='

    def parse(self, response):
        self.type += 1
        for tr in response.css('table tr')[1:]:
            # 处理前台人员
            td = tr.css('td::text').getall()
            td = [a.strip() for a in td]
            if len(td) == 4:
                job = td[0]
            if 3 <= len(td) <= 4:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])
        if self.type == 2:
            yield scrapy.Request(url=self.basic_url+str(self.type), callback=self.parse)
        if self.type == 3:
            yield scrapy.Request(url=self.basic_url + str(self.type), callback=self.parse_back)

    def parse_back(self, response):
        self.type += 1
        for tr in response.css('table tr')[1:]:
            # 处理中后台人员
            td = tr.css('td::text').getall()
            td = [a.strip() for a in td]
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])
        if self.type == 4:
            yield scrapy.Request(url=self.basic_url + str(self.type), callback=self.parse_dis)

    def parse_dis(self, response):
        for tr in response.css('table tr')[1:]:
            td = tr.css('td::text').getall()
            td = [a.strip() for a in td]
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])