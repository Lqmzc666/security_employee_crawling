# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class HongtastockSpider(scrapy.Spider):
    name = 'hongtastock'
    allowed_domains = ['hongtastock.com']
    start_urls = ['http://www.hongtastock.com/News_view.aspx?id=bf8c0c12-79af-4e45-9329-975dc328640a']
    com_name = '红塔证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table.MsoNormalTable')
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td p span::text').getall()
                td = list(filter(None, [a.strip() for a in td]))
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td p *::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for tr in tables[-1].css('tr')[1:]:
            td = tr.css('td p span::text').getall()
            if len(td) > 1:  # 确保不会出现只有一个无或者暂无的情况
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])
