# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
from urllib.parse import urljoin

class FounderscSpider(scrapy.Spider):
    name = 'foundersc'
    allowed_domains = ['foundersc.com']
    start_urls = ['https://www.foundersc.com/bondTradersOn/index.jhtml']
    com_name = '方正证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = ['https://www.foundersc.com/bondTradersOn/index.jhtml',
               'https://www.foundersc.com/bondTradersOff/index.jhtml']
        yield scrapy.Request(url=url[0], callback=self.parse)
        yield scrapy.Request(url=url[1], callback=self.parse_dis)

    def parse(self, response):
        for row in response.css('div.info-tb-tr')[1:]:
            data = row.css('div.td-center::text').getall()[1:]
            final_data = [a.strip() for a in data]
            # 前台人员处理
            if final_data[0] != '债券交易核对专岗':
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'other', 'phone'],
                               [self.com_name, '在职', '前台'] + final_data)
            # 中后台人员处理
            else:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'other', 'phone'],
                               [self.com_name, '在职', '中后台'] + final_data)
         # 翻页处理
        basic_url = 'https://www.foundersc.com/bondTradersOn/'
        if response.css('div.info-btn-page.fr.space a::attr(onclick)').get():
            href = response.css('div.info-btn-page.fr.space a::attr(onclick)').get().split('=')[1][1:-1]  # 去掉冒号
            url = urljoin(basic_url, href)
            yield scrapy.Request(url=url, callback=self.parse)

    # 离职人员处理
    def parse_dis(self, response):
        for row in response.css('div.info-tb-tr')[1:]:
            data = row.css('div.td-center::text').getall()[1:]
            final_data = [a.strip() for a in data]
            if final_data:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + final_data)