# -*- coding: utf-8 -*-
import scrapy


class CnhtSpider(scrapy.Spider):
    name = 'cnht'
    allowed_domains = ['cnht.com.cn']
    start_urls = ['https://www.cnht.com.cn/htzq/public/infodetail_server.jsp?channelid=0&classid=0&infoid=1454706']
    com_name = '恒泰证券股份有限公司'
    author = 'Qi_Li'
    def parse(self, response):
        with open('123.txt', 'wb') as f:
            f.write(response.body)