# -*- coding: utf-8 -*-
import scrapy
from scrapy import Selector
from BondsPractitioners.spiders import set_item

class EstockSpider(scrapy.Spider):
    name = 'estock'
    allowed_domains = ['estock.com.cn']
    start_urls = ['http://www.estock.com.cn/?q=node/209420']
    com_name = '大通证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = Selector(text=response.text).css('table')
        # 处理前台人员
        for table in tables[:2]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td p::text').getall()
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td p::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for rows in tables[-1].css('tr')[1:]:
            td = rows.css('td')  # 会出现一个空格里有两行的情况
            if len(td[0].css('p::text')) > 0:  # 证名文字在p标签底下
                if len(td) != 0:
                    yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty', 'other'],
                                   [self.com_name, '离职'] + td[-5:-1].css('p::text').getall()+[''.join(td[-1].css('p::text').getall())])
            else:
                data = []
                for i in range(-5, -1):
                    data.append(td[i].css('::text').get().strip())  # 没有p标签的会有很多空格
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty', 'other'],
                               [self.com_name, '离职'] + data + [''.join(td[-1].css('p::text').getall())])