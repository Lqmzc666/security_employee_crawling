# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class GkzqSpider(scrapy.Spider):
    name = 'gkzq'
    allowed_domains = ['gkzq.com.cn']
    start_urls = ['http://www.gkzq.com.cn/gkzq/gywm/gywmInfoDetail-zyzt.jsp?classid=0001000100010021']
    com_name = '国开证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')[:-1]
        # 处理前台人员
        for table in tables[:3]:
            for tr in table.css('tr')[1:]:
                td = tr.css('td::text').getall()
                print(len(td))
                if len(td) == 4:
                    job = td[0]
                if 3 <= len(td) <= 4 and td[2].find('无') == -1:  # 确保内容不是暂无
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td::text').getall()
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5 and td[2].find('无') == -1:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for tr in tables[4].css('tr')[1:]:
            td = tr.css('td::text').getall()
            if len(td) != 0 and td[2].find('无') == -1:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])