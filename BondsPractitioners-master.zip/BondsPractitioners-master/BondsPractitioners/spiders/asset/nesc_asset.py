# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
import json
import math

class NescAssetSpider(scrapy.Spider):
    name = 'nesc_asset'
    allowed_domains = ['nesc.cn']
    start_urls = ['http://www.nesc.cn/dbzq/wsyyt/khzq/zyztjyry/zyztjyry_list.jsp?classid=0001000100020001000']
    com_name = '东证融汇证券资产管理有限公司'
    author = 'Qi_Li'

    headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
    post_dict = [{'url': 'http://www.nesc.cn/dbzq/wsyyt/khzq/zgztjyry/getZgztjyry.jsp',
                  'body': 'name=&zw=&classid=53&pageSize=10',
                  'type': 1},
                 {'url': 'http://www.nesc.cn/dbzq/wsyyt/khzq/zgzhthdzg/getZgzhthdzg.jsp',
                  'body': 'name=&gw=&bm=%E8%AF%B7%E9%80%89%E6%8B%A9&classid=54&pageSize=100',
                  'type': 2},
                 {'url': 'http://www.nesc.cn/dbzq/wsyyt/khzq/zglzry/getZglzry.jsp',
                  'body': 'name=&bm=%E8%AF%B7%E9%80%89%E6%8B%A9&classid=55&pageSize=10',
                  'type': 3}]

    def start_requests(self):
        for post in self.post_dict:
            yield scrapy.Request(url=post.get('url'), method='POST', headers=self.headers,
                                 body=post.get('body'), meta=post)

    def parse(self, response):
        meta = response.meta
        for data in json.loads(response.text)['result']:
            if meta.get('type') == 1:
                yield set_item(['com', 'kind', 'state', 'job', 'name', 'duty'],
                               [self.com_name, '前台', '在职', data.get('gw'), data.get('xm'), data.get('zw')])
            if meta.get('type') == 2:
                yield set_item(['com', 'kind', 'state', 'job', 'name', 'duty', 'phone'],
                               [self.com_name, '中后台', '在职', data.get('gw'), data.get('xm'), data.get('zw'),
                                data.get('dh')])
            if meta.get('type') == 3:
                yield set_item(['com', 'state', 'name', 'duty', 'ldate'],
                               [self.com_name, '离职', data.get('xm'), data.get('zw'), data.get('lzrq')])

        result = json.loads(response.text)
        totalCount = result.get('totalCount')
        pageSize = result.get('pageSize')
        pages = math.ceil(totalCount / pageSize)
        for page in range(2, pages + 1):
            yield scrapy.Request(url=meta.get('url'), method='POST', headers=self.headers,
                                 body=meta.get('body') + '&pageIndex=' + str(page), meta=meta)
