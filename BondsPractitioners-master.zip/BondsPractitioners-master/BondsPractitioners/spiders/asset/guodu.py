# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class GuoduSpider(scrapy.Spider):
    name = 'guodu'
    allowed_domains = ['guodu.com']
    start_urls = ['http://www.guodu.com/aboutus/walk_into_guodu_13.jsp']
    com_name = '国都证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        trs = response.css('table[style] tr')
        index = []  # 标记每张表格起始位置
        for i in range(len(trs)):
            td = trs[i].css('td font::text').getall()
            if td:
                if td[0] == '姓名' or td[0] == '岗位分类':
                    index.append(i)

        # 处理前台人员
        for tr in trs[(index[0]+1):(index[3])]:
            td = tr.css('td font::text').getall()
            if td:   #确保td有东西，中间大标题处td为空
                if td[0] != '岗位分类' and len(td)==4:
                    job = td[0]
                if td[0] != '岗位分类' and 3 <= len(td) <=4:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])
#
        # 处理中后台人员
        for tr in trs[(index[3] + 1):(index[4])]:
            td = tr.css('td font::text').getall()
            if td:
                if td[0] != '岗位分类' and len(td) == 5:
                    job = td[0]
                if td[0] != '岗位分类' and 4 <= len(td) <= 5:
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                                   [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for tr in trs[(index[4] + 1):len(trs)]:
            td = tr.css('td *::text').getall()  # 年份在td标签下
            if td:
                if td[0] != '姓名':
                    yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                                   [self.com_name, '离职'] + td[-4:])
