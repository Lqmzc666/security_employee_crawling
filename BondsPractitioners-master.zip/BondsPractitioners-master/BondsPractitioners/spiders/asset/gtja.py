# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item


class GtjaSpider(scrapy.Spider):
    name = 'gtja'
    allowed_domains = ['gtja.com']
    start_urls = ['https://www.gtja.com/content/public-system/bond_exchange.html']
    com_name = '国泰君安证券股份有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')

        # 处理前台人员
        for tr in tables[0].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]
            if len(td) == 4:
                job = td[0]
            if 3 <= len(td) <= 4:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for tr in tables[1].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        yield scrapy.Request(url='https://www.gtja.com/content/public-system/bond_exchange/dimision.html',
                             callback=self.parse_dis)

    # 处理离职人员
    def parse_dis(self, response):
        for tr in response.css('table tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('::text').getall()) for a in td]
            td = list(filter(None, [a.strip() for a in td]))    # 去掉换行符
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])