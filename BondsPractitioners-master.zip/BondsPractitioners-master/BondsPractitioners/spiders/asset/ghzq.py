# -*- coding: utf-8 -*-
import scrapy
import json
from BondsPractitioners.spiders import set_item

class GhzqSpider(scrapy.Spider):
    name = 'ghzq'
    allowed_domains = ['ghzq.com.cn']
    start_urls = ['http://www.ghzq.com.cn/views/publicity.html?tab1=4/']
    com_name = '国海证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'http://www.ghzq.com.cn/gwapi/info/staff/bondTrader/query'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
                   'X-Requested-With': 'XMLHttpRequest'}
        data = [{'pagesize': '50', 'page': '1', 'f_type': '1', 'f_in_service': 'Y'},
                {'pagesize': '50', 'page': '1', 'f_type': '2', 'f_in_service': 'Y'},
                {'pagesize': '50', 'page': '1', 'f_type': '3', 'f_in_service': 'Y'},
                {'pagesize': '50', 'page': '1', 'f_in_service': 'N'}]
        for i in data[:2]:
            yield scrapy.FormRequest(url=url, headers=headers, formdata=i, method='POST', callback=self.parse_front)
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[2], method='POST', callback=self.parse_back)
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[3], method='POST', callback=self.parse_dis)

    # 处理前台人员
    def parse_front(self, response):
        results = json.loads(response.text).get('data')
        for result in results:
            data = ['f_position', 'f_name', 'f_dept', 'f_job']
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '在职', '前台'] + [result.get(a) for a in data])

    # 处理中后台人员
    def parse_back(self, response):
        results = json.loads(response.text).get('data')
        for result in results:
            data = ['f_position', 'f_name', 'f_dept', 'f_job', 'f_phone']
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '在职', '中后台'] + [result.get(a) for a in data])

    # 处理离岗人员
    def parse_dis(self, response):
        results = json.loads(response.text).get('data')
        for result in results:
            data = ['f_name', 'f_departure_time', 'f_dept', 'f_job']
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + [result.get(a) for a in data])

