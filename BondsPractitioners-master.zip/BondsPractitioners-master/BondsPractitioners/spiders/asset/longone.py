# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item

class LongoneSpider(scrapy.Spider):
    name = 'longone'
    allowed_domains = ['longone.com']
    start_urls = ['http://www.longone.com.cn/main/a/article/index.html?article_id=13908352/']
    com_name = '东海证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'http://www.longone.com.cn/servlet/Article?function=getArticleContent'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
                   'X-Requested-With': 'XMLHttpRequest'}
        data = [{'articleId': '13907531'},
                {'articleId': '13908351'}]
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[0], method='POST', callback=self.parse_asset)  # 资管
        yield scrapy.FormRequest(url=url, headers=headers, formdata=data[1], method='POST', callback=self.parse_bond)  # 证券

    def parse_asset(self, response):
        tables = response.css('table')
        # 处理前台人员
        for rows in tables[0].css('tr')[1:]:
            td = rows.css('td::text').getall()
            if len(td) == 4:
                job = td[0]
            if 3 <= len(td) <= 4:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for rows in tables[1].css('tr')[1:]:
            td = rows.css('td span::text').getall()  # 有的电话外层没有p标签
            try:
                td.remove('\xa0')
            except:
                pass
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for rows in tables[2].css('tr')[1:]:
            td = rows.css('td::text').getall()
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])

    def parse_bond(self, response):
        tables = response.css('table')
        # 处理前台人员
        for rows in tables[0].css('tr')[1:]:
            td = rows.css('td p span::text').getall()
            if len(td) == 4:
                job = td[0]
            if 3 <= len(td) <= 4:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job] + td[-3:])

        # 处理中后台人员
        for rows in tables[1].css('tr')[1:]:
            td = rows.css('td p span::text').getall()  # 有的电话外层没有p标签
            try:
                td.remove('\xa0')
            except:
                pass
            if len(td) == 5:
                job = td[0]
            if 4 <= len(td) <= 5:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job] + td[-4:])

        # 处理离职人员
        for rows in tables[2].css('tr')[1:]:     # 年份被拆开了
            td = rows.css('td')
            if len(td.css('p span::text')) != 0:
                data = [''.join(tx.css('p span::text').getall()) for tx in td]
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + data[-4:])