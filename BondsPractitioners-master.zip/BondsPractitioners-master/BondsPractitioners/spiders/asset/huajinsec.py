# -*- coding: utf-8 -*-
import scrapy
import json
from BondsPractitioners.spiders import set_item


class HuajinsecSpider(scrapy.Spider):
    name = 'huajinsec'
    allowed_domains = ['huajinsc.cn']
    start_urls = ['https://www.huajinsc.cn/HJ_GW_001/gw_hjyw/gw_hjdzg/dzg_tdjs/zg_rygs/index.html?nodeName=1/']
    data = [{'funcNo': '822000', 'numPerPage': '8', 'curPage': '1', 'personnel_type': '1'},  # 资管
            {'funcNo': '822000', 'numPerPage': '8', 'curPage': '1', 'personnel_type': '2'},  # 自营债券
            {'funcNo': '822002', 'numPerPage': '8', 'curPage': '1', 'personnel_type': '2'},  # 中后台
            {'funcNo': '822003', 'numPerPage': '8', 'curPage': '1', 'personnel_type': '1'}]  # 离职
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest'}
    curPage = 1
    com_name = '华金证券股份有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = 'https://www.huajinsc.cn/servlet/json'
        yield scrapy.FormRequest(url=url, headers=self.headers, formdata=self.data[0], method='POST', callback=self.parse_front_asset)
        yield scrapy.FormRequest(url=url, headers=self.headers, formdata=self.data[1], method='POST', callback=self.parse_front_bond)
        yield scrapy.FormRequest(url=url, headers=self.headers, formdata=self.data[2], method='POST', callback=self.parse_back)
        yield scrapy.FormRequest(url=url, headers=self.headers, formdata=self.data[3], method='POST', callback=self.parse_dis)

    # 处理前台人员
    def parse_front_asset(self, response):
        total_page = json.loads(response.text).get('results')[0].get('totalPages')
        results = json.loads(response.text).get('results')[0].get('data')
        index = ['jurisdiction', 'personnel_name', 'personnel_department', 'practice_no']
        for result in results:
            data_ = [result.get(a) for a in index]
            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '前台', '在职'] + data_)
        for i in range(2, total_page+1):
            self.data[0]['curPage'] = str(i)
            yield scrapy.FormRequest(url=response.url, headers=self.headers, formdata=self.data[0],
                                     method='POST', callback=self.parse_front_asset)

    def parse_front_bond(self, response):
        total_page = json.loads(response.text).get('results')[0].get('totalPages')
        results = json.loads(response.text).get('results')[0].get('data')
        index = ['jurisdiction', 'personnel_name', 'personnel_department', 'practice_no']
        for result in results:
            data_ = [result.get(a) for a in index]
            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty'],
                           [self.com_name, '前台', '在职'] + data_)
        for i in range(2, total_page+1):
            self.data[1]['curPage'] = str(i)
            yield scrapy.FormRequest(url=response.url, headers=self.headers, formdata=self.data[1],
                                     method='POST', callback=self.parse_front_bond)

    # 处理中后台人员
    def parse_back(self, response):
        total_page = json.loads(response.text).get('results')[0].get('totalPages')
        results = json.loads(response.text).get('results')[0].get('data')
        index = ['jurisdiction', 'personnel_name', 'personnel_department', 'practice_no', 'fixed_telephone']
        for result in results:
            data_ = [result.get(a) for a in index]
            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty', 'phone'],
                           [self.com_name, '中后台', '在职'] + data_)

        for i in range(2, total_page + 1):
            self.data[2]['curPage'] = str(i)
            yield scrapy.FormRequest(url=response.url, headers=self.headers, formdata=self.data[2],
                                     method='POST', callback=self.parse_back)

    # 处理离职人员
    def parse_dis(self, response):
        total_page = json.loads(response.text).get('results')[0].get('totalPages')
        results = json.loads(response.text).get('results')[0].get('data')
        index = ['personnel_name', 'creation_time', 'personnel_department', 'practice_no']
        for result in results:
            data_ = [result.get(a) for a in index]
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + data_)

        for i in range(2, total_page + 1):
            self.data[3]['curPage'] = str(i)
            yield scrapy.FormRequest(url=response.url, headers=self.headers, formdata=self.data[3],
                                     method='POST', callback=self.parse_dis)
        data = {'funcNo': '822003', 'numPerPage': '8', 'curPage': '1', 'personnel_type': '2'}
        yield scrapy.FormRequest(url=response.url, headers=self.headers, formdata=data,
                                 method='POST', callback=self.parse_dis)