# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item


class GwgscSpider(scrapy.Spider):
    name = 'gwgsc'
    allowed_domains = ['gwgsc.com']
    start_urls = ['https://www.gwgsc.com/main/zjccgr/xxgs/zqjyry/index.shtml#mark/']
    com_name = '长城国瑞证券有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        #处理前台在职人员
        for tr in tables[0].css('tr')[1:]:
            td = tr.css('td')
            if len(td) == 4:
                job = ''.join(td[0].css('p span::text').getall())
            if 3 <= len(td) <= 4:
                data = td[-3].css('p span::text').get()
                if len(data.split(' ')) > 1:
                    data = (data.split(' ')[0] + data.split(' ')[1][-1]).strip()
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job, data, ''.join(td[-2].css('p span::text').getall()), td[-1].css('p span::text').get()])

        for tr in tables[1].css('tr')[1:]:
            td = tr.css('td')
            if len(td) == 4:
                job = ''.join(td[0].css('p span::text').getall())
            if 3 <= len(td) <= 4:
                data = td[-3].css('p span::text').get()
                if len(data.split(' ')) > 1:
                    data = (data.split(' ')[0] + data.split(' ')[1][-1]).strip()
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                               [self.com_name, '在职', '前台', job, data, ''.join(td[-2].css('p span::text').getall()), td[-1].css('p span::text').get()])

        #处理中后台人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td')
            if len(td) == 5:
                job = ''.join(td[0].css('p span::text').getall())
            if 4 <= len(td) <= 5:
                data = td[-4].css('p span::text').get()
                if len(data.split(' ')) > 1:
                    data = (data.split(' ')[0] + data.split(' ')[1][-1]).strip()
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台', job, data, ''.join(td[-3].css('p span::text').getall())]+td[-2:].css('p span::text').getall())

        #处理离职人员
        for tr in tables[3].css('tr')[1:]:
            td = tr.css('td p span::text')
            if len(td) != 0:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td.getall()[-4:])