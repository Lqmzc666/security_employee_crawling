# -*- coding: utf-8 -*-
import scrapy
import os
import pdfplumber
from BondsPractitioners.spiders import set_item


class HsqhfundsSpider(scrapy.Spider):
    name = 'hsqhfunds'
    allowed_domains = ['hsqhfunds.com']
    start_urls = ['https://www.hsqhfunds.com/upload/user/1/2018-11-26/195400946644.pdf']
    com_name = '恒生前海基金管理有限公司'

    def parse(self, response):
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'hsqhfunds.pdf')
        with open(file_name, 'wb') as f:
            f.write(response.body)

        tables = []
        with pdfplumber.open(file_name) as pdf:
            for page in pdf.pages:
                for table in page.extract_tables():
                    for data in table:
                        tables.append([row for row in data if row])

        tables = [table for table in tables if len(table) > 2]
        index = []  # 标记每张表格起始位置
        i = 0
        for table in tables:
            if table:
                if table[0] == '职能分类' or table[0] == '姓名':
                    index.append(i)
            i += 1

        # 处理在职人员
        kind = '业务人员'
        for i in range(index[0] + 1, index[1]):
            if len(tables[i]) == 6:
                kind = tables[i][0]
            if kind == '业务人员':
                if 4 <= len(tables[i]) <= 5:
                    job = tables[i][-4]
                if tables[i][-3] != '-':
                    yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '前台', '在职', job] + tables[i][-3:])
            if kind != '业务人员':
                if 5 <= len(tables[i]) <= 6:
                    job = tables[i][-5]
                if tables[i][-4] != '-':
                    yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'duty', 'phone'],
                                   [self.com_name, '中后台', '在职', job] + tables[i][-4:])

        for i in range(index[1] + 1, len(tables)):
            if len(tables[i]) == 4:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + tables[i])

