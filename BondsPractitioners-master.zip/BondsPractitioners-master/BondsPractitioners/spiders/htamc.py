# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *


class HtamcSpider(scrapy.Spider):
    name = 'htamc'
    allowed_domains = ['htamc.com.cn']
    start_urls = ['http://www.htamc.com.cn/main/abouts/rygs/index.shtml']
    com_name = '红塔红土基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        table = response.css('table')
        trs = table[0].css('tr')[1:]
        tds = []
        for tr in trs:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            td = [a.strip() for a in td]
            tds.append(td)
        index = []  # 标记每张表格起始位置
        i = 0
        for row in tds:
            if row[0] == '职能分类':
                index.append(i)
            i += 1
        index.append(len(tds))

        kind = '业务人员'
        for j in range(len(index)):
            if j % 2 == 0: #判断是在职还是离职
                for i in range(index[j] + 1, index[j+1]-1):
                    if len(tds[i]) == 8:
                        kind = tds[i][0]
                    if kind == '业务人员':
                        if 7 <= len(tds[i]) <= 8:
                            job = tds[i][-7]
                        if tds[i][-6] != '':
                            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'other', 'code', 'duty', 'phone'],
                                           [self.com_name, '前台', '在职', job] + tds[i][-6:])
                    if kind != '业务人员':
                        if 7 <= len(tds[i]) <= 8:
                            job = tds[i][-7]
                        if tds[i][-6] != '':
                            yield set_item(['com', 'kind', 'state', 'job', 'name', 'dpt', 'other', 'code', 'duty', 'phone'],
                                           [self.com_name, '中后台', '在职', job] + tds[i][-6:])
            else:
                for i in range(index[j] + 1, index[j + 1]-2):
                    if tds[i][-6] != '':
                        yield set_item(['com', 'state', 'job', 'name', 'dpt', 'ldate', 'code', 'duty', 'phone'],
                                       [self.com_name, '离职'] + tds[i][1:])
