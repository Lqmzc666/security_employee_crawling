# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *

class ByfundsSpider(scrapy.Spider):
    name = 'byfunds'
    allowed_domains = ['byfunds.com']
    start_urls = ['http://www.byfunds.com/gywm/index.jsp?id=99']
    com_name = '宝盈基金管理有限公司'
    author = 'Qi_Li'

    def start_requests(self):
        url = self.start_urls[0]
        headers = {'Cookie': 'SESSIONID=72F66F0C8F0506E07473FD3787746965; Hm_lvt_38f2c8acbdfe70a1335cb8b7e571f311=1564626147; Hm_lpvt_38f2c8acbdfe70a1335cb8b7e571f311=1564626187; D9xMFwMa0bMlSae=KaKHY46b0IqUAvGhBj2s7iCFMgh_28798GqWbTgQV_kcRne84KbyZSZE3E1Q6iDFq3nRGjFKsZaT9_L5ETShjIoXEpHr4pPSiGfrcV55EV36p'}
        yield scrapy.Request(url=url,headers=headers)

    def parse(self, response):
        print(response)