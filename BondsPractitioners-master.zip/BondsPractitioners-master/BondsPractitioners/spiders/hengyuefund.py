# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *


class HengyuefundSpider(scrapy.Spider):
    name = 'hengyuefund'
    allowed_domains = ['hengyuefund.com']
    start_urls = ['http://www.hengyuefund.com/aboutus/zqjy/index.html']
    com_name = '恒越基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        table = response.css('table')
        for tr in table[0].css('tr')[3:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            yield set_item(['com', 'state', 'kind', 'name', 'dpt', 'other', 'duty', 'code', 'phone'],
                           [self.com_name, '在职', '前台'] + td)