# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import set_item
from BondsPractitioners.spiders import doc2docx
from docx import Document
import os


class CtfundSpider(scrapy.Spider):
    name = 'ctfund'
    allowed_domains = ['ctfund.com']
    start_urls = ['http://www.ctfund.com/contents/2018/12/20-70826fe4ad9b4a43b4f4e8c60858f818.html']
    com_name = '财通基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        link = response.css('li a::attr(href)')[1].get()
        basic_url = 'http://www.ctfund.com'
        yield scrapy.Request(url=basic_url+link, callback=self.parse_word)

    def parse_word(self, response):
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'ctfund.doc')
        with open(file_name, 'wb') as f:
            f.write(response.body)

        doc2docx(file_name)
        # 读取docx文件
        document = Document(os.path.join(file_path, 'ebscn.docx'))
        tables = document.tables

        # 处理前台人员
        for i in range(1, len(tables[0].rows)):
            data = [tables[0].cell(i, j).text for j in range(1, 6)]
            if data[0] != '债券交易核对专岗' and data[-4]:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty','phone'],
                               [self.com_name, '在职', '前台'] + data)
            elif data[0] == '债券交易核对专岗' and data[-4]:
                yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                               [self.com_name, '在职', '中后台'] + data)

        for i in range(1, len(tables[1].rows)):
            data = [tables[1].cell(i, j).text for j in range(0, 4)]
            yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                           [self.com_name, '离职'] + data)