# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *

class CdbsfundSpider(scrapy.Spider):
    name = 'cdbsfund'
    allowed_domains = ['cdbsfund.com']
    start_urls = ['http://www.cdbsfund.com/main/gywm/zzcx/index.shtml']
    com_name = '国开泰富基金管理有限责任公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        for tr in tables[0].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            if len(td) > 4:
                td = td[1:]
            td = [a.strip() for a in td]
            if len(td) == 4:
                job = td[0]
            if 3 <= len(td) <= 4:
                if job != '债券交易核对专岗' and td[-3] != '' and td[-3] != '-' and td[-3] != '无':
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '前台', job] + td[-3:])
                elif job == '债券交易核对专岗' and td[-3] != '' and td[-3] != '-' and td[-3] != '无':
                    yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职', '中后台', job] + td[-3:])

'''  无离职人员
            for tr in tables[1].css('tr')[1:]:
                td = tr.css('td')
                td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
                td = list(filter(None, [a.strip() for a in td]))
                if len(td) > 2:
                    yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                                   [self.com_name, '离职'] + td[-4:])
'''
