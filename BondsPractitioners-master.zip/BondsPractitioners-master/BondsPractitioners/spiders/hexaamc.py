# -*- coding: utf-8 -*-
import scrapy
import os
import pdfplumber
from BondsPractitioners.spiders import set_item


class HexaamcSpider(scrapy.Spider):
    name = 'hexaamc'
    allowed_domains = ['hexaamc.com']
    start_urls = ['http://www.hexaamc.com/front/contentDetail_100354_10569.jhtml']
    com_name = '蜂巢基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        url = response.css('div.download-content *::attr(href)').getall()[0]
        basic_url = 'http://www.hexaamc.com'
        yield scrapy.Request(url=basic_url+url, callback=self.parse_pdf)

    def parse_pdf(self, response):
        file_path = self.settings.get('FILES_STORE')
        file_name = os.path.join(file_path, 'hexaamc.pdf')
        with open(file_name, 'wb') as f:
            f.write(response.body)

        tables = []
        with pdfplumber.open(file_name) as pdf:
            for page in pdf.pages:
                for table in page.extract_tables():
                    for data in table:
                        tables.append([row for row in data if row])

        tables = [table for table in tables if table]
        index = []  # 标记每张表格起始位置
        i = 0
        for table in tables:
            if table:
                if table[0] == '职能分类' or table[0] == '姓名':
                    index.append(i)
            i += 1

        # 处理在职人员
        for i in range(index[0] + 1, index[1]):
            if tables[i][-1] == '-':  #有的空格里没有-
                if tables[i][-4] != '-':
                    yield set_item(['com', 'kind', 'name', 'dpt', 'duty', 'phone'],
                                   [self.com_name, '在职'] + tables[i][-4:])
            elif len(tables[i]) >= 3:
                if tables[i][-3] != '-':
                    yield set_item(['com', 'kind', 'name', 'dpt', 'duty'],
                                   [self.com_name, '在职'] + tables[i][-3:])

        for i in range(index[1] + 1, len(tables)):
            if len(tables[i]) == 4 and tables[i][0] != '-':
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + tables[i])

