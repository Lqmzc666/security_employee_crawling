# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *


class EpfSpider(scrapy.Spider):
    name = 'epf'
    allowed_domains = ['epf.com.cn']
    start_urls = ['http://www.epf.com.cn/service/Investment.shtml']
    com_name = '光大保德信基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table.table_hd')

        #处理前台人员
        for tr in tables[0].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone', 'code'],
                           [self.com_name, '在职', '前台']+td)

        #处理中后台人员
        for tr in tables[1].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone', 'code', 'other'],
                           [self.com_name, '在职', '中后台']+td)

        #处理了离职人员
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            if len(td) > 2:
                yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                               [self.com_name, '离职'] + td[-4:])