# -*- coding: utf-8 -*-
import scrapy
from BondsPractitioners.spiders import *


class GffundsSpider(scrapy.Spider):
    name = 'gffunds'
    allowed_domains = ['gffunds.com.cn']
    start_urls = ['http://www.gffunds.com.cn/143/201201/t20120104_17786.shtml']
    com_name = '广发基金管理有限公司'
    author = 'Qi_Li'

    def parse(self, response):
        tables = response.css('table')
        type = ''
        for tr in tables[2].css('tr')[1:]:
            td = tr.css('td')
            td = [''.join(a.css('*::text').getall()) for a in td]  # 将span中的文字拼接起来
            td = [a.strip() for a in td]
            print(td)
            if len(td) < 3:
                continue
            if td[0] in ['职能分类', '姓名']:
                kind = td[0]
            if kind == '职能分类' and td[0] not in ['职能分类', '姓名']:
                if len(td) > 5:
                    td = td[1:]
                if len(td) == 5:
                    job = td[0]
                if 4 <= len(td) <= 5:
                    if job != '债券交易核对专岗' and td[-4] != '' and td[-4] != '-' and td[-4] != '无':
                        yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                                       [self.com_name, '在职', '前台', job] + td[-4:])
                    elif job == '债券交易核对专岗' and td[-4] != '' and td[-4] != '-' and td[-4] != '无':
                        yield set_item(['com', 'state', 'kind', 'job', 'name', 'dpt', 'duty', 'phone'],
                                       [self.com_name, '在职', '中后台', job] + td[-4:])
            if kind == '姓名' and td[0] not in ['职能分类', '姓名']:
                if len(td) > 2:
                    yield set_item(['com', 'state', 'name', 'ldate', 'dpt', 'duty'],
                                   [self.com_name, '离职'] + td[-4:])
