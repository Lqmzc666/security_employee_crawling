import requests
from bs4 import BeautifulSoup
import pyexcel as pe

url = 'http://www.essence.com.cn/emp/bond'
headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:67.0) Gecko/20100101 Firefox/67.0'}
res = requests.get(url=url, headers=headers).text
soup = BeautifulSoup(res, 'lxml')

sr = [list(map(lambda y: y.string, x.select('td')))
      for x in soup.select('div .sr-wrap')[0].select('tr')[1:]]
asset = [list(map(lambda y: y.string, x.select('td')))
         for x in soup.select('div .asset-wrap')[0].select('tr')[1:]]

pe.save_as(dest_file_name='axzq.xlsx', array=sr + asset)
