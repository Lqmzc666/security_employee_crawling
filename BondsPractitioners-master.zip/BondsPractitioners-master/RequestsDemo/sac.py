import requests
import pyexcel as pe

url = 'http://jg.sac.net.cn/pages/publicity/resource!search.action'
headers = {'Content-Type': 'application/x-www-form-urlencoded',
           'X-Requested-With': 'XMLHttpRequest'}
body = ['filter_EQS_OTC_ID=1100&filter_LIKES_AOI_NAME=&sqlkey=publicity&sqlval=BONDTRADER_INFO',
        'filter_EQS_OTC_ID=1199&filter_LIKES_AOI_NAME=&sqlkey=publicity&sqlval=BONDTRADER_INFO']

result = [[y.get('AOI_NAME'), y.get('BTI_PUBLICITY_PAGE_LINK')]
          for x in body
          for y in requests.post(url=url, headers=headers, data=x).json()]

pe.save_as(dest_file_name='sac.xlsx', array=result)
